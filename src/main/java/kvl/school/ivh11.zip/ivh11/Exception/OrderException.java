package kvl.school.ivh11.exception;

public class OrderException extends Exception
{
    public OrderException(String message)
    {
        super(message);
    }

}
