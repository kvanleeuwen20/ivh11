package kvl.school.ivh11.exception;

public class PaymentException extends Exception
{
    public PaymentException(String message)
    {
        super(message);
    }
}