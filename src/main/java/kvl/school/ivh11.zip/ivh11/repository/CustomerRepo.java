package kvl.school.ivh11.repository;

import kvl.school.ivh11.domain.Customer;

public interface CustomerRepo extends BaseRepo<Customer, Long> {
}
