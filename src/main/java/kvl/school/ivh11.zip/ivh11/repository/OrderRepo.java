package kvl.school.ivh11.repository;

import kvl.school.ivh11.domain.Order;

public interface OrderRepo extends BaseRepo<Order, Long>
{

}