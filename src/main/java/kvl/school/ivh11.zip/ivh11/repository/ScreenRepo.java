package kvl.school.ivh11.repository;

import kvl.school.ivh11.domain.Screen;

public interface ScreenRepo extends BaseRepo<Screen, Long> {
}
