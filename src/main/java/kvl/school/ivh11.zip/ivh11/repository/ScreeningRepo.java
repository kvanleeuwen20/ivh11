package kvl.school.ivh11.repository;

import kvl.school.ivh11.domain.Screening;

public interface ScreeningRepo extends BaseRepo<Screening, Long> {
}
