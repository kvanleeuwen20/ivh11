package kvl.school.ivh11.repository;

import kvl.school.ivh11.domain.Ticket;

public interface TicketRepo extends BaseRepo<Ticket, Long>
{

}