package kvl.school.ivh11.repository;

import kvl.school.ivh11.domain.Employee;

public interface EmployeeRepo extends BaseRepo<Employee, Long>{
}
