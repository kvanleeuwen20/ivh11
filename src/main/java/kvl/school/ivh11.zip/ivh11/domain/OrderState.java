package kvl.school.ivh11.domain;

public enum OrderState
{
    OPEN, PENDING, PAID, FAILED
}
