package kvl.school.ivh11.domain.abstr;

import javax.naming.Context;

public interface OrderStateIF
{
    public void processAction(Context context);
}