package kvl.school.ivh11.service.impl;

import kvl.school.ivh11.service.abstr.CommunicationHandler;

public class EmailHandler extends CommunicationHandler
{
    public EmailHandler(EmailData data)
    {
        super(data);
    }

    @Override
    protected void setReceiver()
    {

    }

    @Override
    protected void setContent()
    {

    }
}
