package kvl.school.ivh11.service.abstr;

import kvl.school.ivh11.domain.Cinema;

public interface CinemaService
{
    Cinema findCinemasWithId(long id);
}
