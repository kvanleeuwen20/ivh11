package kvl.school.ivh11.service.abstr;

import java.util.HashMap;

public interface PSPContract
{
    void setConfigParams(HashMap<String, String> cnf);
}
