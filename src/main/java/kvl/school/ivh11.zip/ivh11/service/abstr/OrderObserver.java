package kvl.school.ivh11.service.abstr;

public abstract class OrderObserver
{
}
