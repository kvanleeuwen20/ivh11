package kvl.school.ivh11.service.abstr;

import kvl.school.ivh11.domain.Screening;

public interface OrderService
{
    void addTicket(Screening screening);
}
