package kvl.school.ivh11.service;

public class PaymentState
{
    private String state;

    public PaymentState(String state)
    {
        this.state = state;
    }

    public String getState()
    {
        return state;
    }
}
